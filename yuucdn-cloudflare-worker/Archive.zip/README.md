# YuuCDN Cloudflare Worker Proxy & Caching

Worker ini berfungsi untuk mem-proxy request gambar dari YuuCDN dengan menyematkan header yang tepat (`access-code` dan `referer`) serta menyimpan (cache) respon gambar di Edge Network Cloudflare menggunakan Cache API.

Hal ini memecahkan masalah:
1. **IP VPS Terblokir**: Worker berjalan pada IP Cloudflare Edge.
2. **Hemat Bandwidth Webshare/Proxy**: Mengurangi request ke YuuCDN secara masif melalui mekanisme caching.
3. **Hemat Bandwidth VPS**: Gambar dikirimkan langsung dari Worker Cloudflare ke browser user tanpa melewati server backend NodeJS Anda.

---

## 🚀 Cara Setup dan Deploy

### 1. Persiapan
Pastikan Anda memiliki [NodeJS](https://nodejs.org/) terinstal di mesin lokal Anda.

Masuk ke direktori worker:
```bash
cd yuucdn-cloudflare-worker
```

Instal dependensi (Wrangler):
```bash
npm install
```

### 2. Login ke Cloudflare
Jalankan perintah berikut untuk login menggunakan akun Cloudflare Anda:
```bash
npx wrangler login
```

### 3. Deploy Worker
Deploy proyek worker ke Cloudflare:
```bash
npx wrangler deploy
```

Setelah berhasil ter-deploy, Anda akan mendapatkan URL Worker Anda, contohnya:
`https://yuucdn-proxy.<your-subdomain>.workers.dev`

---

## ⚙️ Integrasi dengan Backend Komiknesia

Untuk mengarahkan semua url gambar YuuCDN langsung ke Cloudflare Worker (sehingga tidak membebani server backend atau kuota proxy webshare Anda):

1. Buka file `.env` di direktori backend NodeJS Anda.
2. Tambahkan variabel lingkungan baru:
   ```env
   YUUCDN_WORKER_URL=https://yuucdn-proxy.<your-subdomain>.workers.dev
   ```
3. Restart backend NodeJS Anda.

---

## 🔍 Cara Verifikasi & Testing
Anda bisa mengetes performa caching dengan membuka url gambar secara langsung pada browser, misalnya:
`https://yuucdn-proxy.<your-subdomain>.workers.dev/wp-content/uploads/imgsc/m/mairimashita-iruma-kun/448/1.jpg`

Buka **Chrome DevTools -> Network**, klik pada request gambar, lalu periksa response headers-nya:
- **X-Proxy-Cache**:
  - `MISS` pada request pertama (worker mengambil gambar ke YuuCDN).
  - `HIT` pada request kedua dan seterusnya (gambar dilayani langsung dari Cache Cloudflare, instan dan hemat kuota).
